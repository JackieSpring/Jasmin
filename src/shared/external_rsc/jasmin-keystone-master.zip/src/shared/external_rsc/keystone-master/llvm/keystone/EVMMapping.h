#ifndef KS_EVMMAPPING_H
#define KS_EVMMAPPING_H

// find opcode of this mnemonic, or return -1 on failure
unsigned short EVM_opcode(const char *mnemonic);

#endif
