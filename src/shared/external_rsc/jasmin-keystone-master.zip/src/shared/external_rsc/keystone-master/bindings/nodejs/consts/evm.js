// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [evm_const.js]
module.exports.ERR_ASM_EVM_INVALIDOPERAND = 512
module.exports.ERR_ASM_EVM_MISSINGFEATURE = 513
module.exports.ERR_ASM_EVM_MNEMONICFAIL = 514
