// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [mips_const.js]
module.exports.ERR_ASM_MIPS_INVALIDOPERAND = 512
module.exports.ERR_ASM_MIPS_MISSINGFEATURE = 513
module.exports.ERR_ASM_MIPS_MNEMONICFAIL = 514
