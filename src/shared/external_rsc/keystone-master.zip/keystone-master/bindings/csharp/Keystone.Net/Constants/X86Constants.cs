// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [x86Constants.cs]
namespace Keystone
{
	public enum X86Error : short
	{
		KS_ERR_ASM_X86_INVALIDOPERAND = 512,
		KS_ERR_ASM_X86_MISSINGFEATURE = 513,
		KS_ERR_ASM_X86_MNEMONICFAIL = 514,
	}
}