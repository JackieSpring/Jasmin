#include "keystone_wrapper.h"

void ks_close_wrapper(ks_engine *ks) {
    ks_close(ks);
}
